﻿$script:playbackFile=Join-Path $script:dataDir 'oynatma.json'
$script:pendingSeek=$null
$script:closingAll=$false
$script:lastPlaybackSave=[DateTime]::UtcNow
if(-not ('AteshMediaKeys' -as [type])){Add-Type -Path (Join-Path $homeDir 'MediaKeys.cs') -ReferencedAssemblies @('System.dll',[Windows.DependencyObject].Assembly.Location,[Windows.Media.Imaging.BitmapSource].Assembly.Location)}
[xml]$miniXaml=Get-Content -LiteralPath (Join-Path $homeDir 'MiniPlayer.xaml') -Raw -Encoding UTF8
$script:mini=[Windows.Markup.XamlReader]::Load([Xml.XmlNodeReader]::new($miniXaml))
$mini.Resources=$window.Resources
$script:miniUi=@{}
foreach($name in 'MiniDrag,MiniPin,MiniExpand,MiniClose,MiniCover,MiniTitle,MiniArtist,MiniTime,MiniDuration,MiniSeek,MiniPrev,MiniPlay,MiniNext,MiniVolume'.Split(',')){$miniUi[$name]=$mini.FindName($name)}
function Sync-Mini {
 $miniUi.MiniTitle.Text=$ui.NowTitle.Text;$miniUi.MiniArtist.Text=$ui.NowArtist.Text;$miniUi.MiniCover.Source=$ui.NowCover.Source
 $miniUi.MiniPlay.Content=if($script:playing){'Ⅱ'}else{'▶'}
 $miniUi.MiniTime.Text=$ui.Elapsed.Text;$miniUi.MiniDuration.Text=$ui.Duration.Text
 $miniUi.MiniSeek.Maximum=$ui.Seek.Maximum
 if(-not $miniUi.MiniSeek.IsMouseCaptureWithin){$miniUi.MiniSeek.Value=$ui.Seek.Value}
 $miniUi.MiniVolume.Value=$ui.Volume.Value
}
function Save-Playback {
 try{
  $position=if($null -ne $script:pendingSeek){$script:pendingSeek}elseif($script:current){$player.Position.TotalSeconds}else{0}
  $state=@{TrackId=$(if($script:current){$script:current.Id}else{$null});Position=[Math]::Max(0.0,[double]$position);Volume=$ui.Volume.Value;Shuffle=$script:shuffle;Repeat=$script:repeat;Motion=$script:motionEnabled;Pinned=$mini.Topmost}
  $json=$state | ConvertTo-Json
  [IO.File]::WriteAllText("$script:playbackFile.tmp",$json,[Text.UTF8Encoding]::new($true))
  Move-Item -LiteralPath "$script:playbackFile.tmp" -Destination $script:playbackFile -Force
  $script:lastPlaybackSave=[DateTime]::UtcNow
 }catch{$ui.Status.Text='Son oynatma konumu kaydedilemedi.'}
}
function Restore-Playback {
 if(-not (Test-Path -LiteralPath $script:playbackFile)){return}
 try{
  $state=Get-Content -LiteralPath $script:playbackFile -Raw -Encoding UTF8 | ConvertFrom-Json
  if($null -ne $state.Volume){$volume=[double]$state.Volume;if(-not [double]::IsNaN($volume) -and -not [double]::IsInfinity($volume)){$ui.Volume.Value=[Math]::Max(0.0,[Math]::Min(1.0,$volume))}}
  $script:shuffle=($state.Shuffle -eq $true);$script:repeat=($state.Repeat -eq $true)
  if($null -ne $state.Motion){$script:motionEnabled=($state.Motion -eq $true)}
  if($null -ne $state.Pinned){$mini.Topmost=($state.Pinned -eq $true)}
  $ui.Shuffle.Background=if($script:shuffle){'#702333'}else{'Transparent'};$ui.Repeat.Background=if($script:repeat){'#702333'}else{'Transparent'}
  $ui.MotionToggle.Content=if($script:motionEnabled){'3D • Açık'}else{'3D • Sabit'}
  $miniUi.MiniPin.Content=if($mini.Topmost){'Üstte ✓'}else{'Üstte'}
  $track=$library | Where-Object Id -eq $state.TrackId | Select-Object -First 1
  if($track -and (Test-Path -LiteralPath $track.Path)){
   $position=[double]$state.Position;if([double]::IsNaN($position) -or [double]::IsInfinity($position)){$position=0}
   Start-Track $track $false ([Math]::Max(0.0,[double]$position))
   $ui.Status.Text='Kaldığın yer hazır. Devam etmek için oynat düğmesine bas.'
  }elseif($state.TrackId){$ui.Status.Text='Son şarkının dosyası bulunamadı. Kütüphaneden başka bir şarkı seçebilirsin.'}
  Sync-Mini
 }catch{$ui.Status.Text='Son oynatma ayarları okunamadı; varsayılan ayarlarla devam ediliyor.'}
}
function Update-SocialLocalPreview {
 if($script:view -ne 'social' -or -not $ui.SocialUsers){return}
 try {
  $name=[string]$script:socialState.Username
  $isPlaying=[bool]($script:current -and $script:playing)
  $trackText=if($isPlaying){[string]$script:current.Title+$(if($script:current.Artist){' · '+[string]$script:current.Artist}else{''})}else{'Çevrimiçi'}
  $activityLabel=if($isPlaying){'ŞİMDİ DİNLİYOR'}else{'AKTİF'}
  $initial=if($name){$name.Substring(0,1).ToUpperInvariant()}else{'A'}
  $old=@($ui.SocialUsers.ItemsSource)
  $existing=$old | Where-Object {([string]$_.UserId -eq [string]$script:socialState.UserId) -or ([string]$_.Username -eq $name)} | Select-Object -First 1
  $others=@($old | Where-Object {-not (([string]$_.UserId -eq [string]$script:socialState.UserId) -or ([string]$_.Username -eq $name))})

  # Anlık şarkı değişiminde kartı baştan eksik nesneyle kurma. Profil/avatar verisini koru.
  $bio=if($existing){[string]$existing.Bio}else{[string]$script:socialState.Bio}
  $avatar=if($existing){[string]$existing.AvatarUrl}else{[string]$script:socialState.AvatarUrl}
  if([string]$script:socialState.LocalAvatarPath -and (Test-Path -LiteralPath ([string]$script:socialState.LocalAvatarPath))){
   try{$avatar=([Uri]([string]$script:socialState.LocalAvatarPath)).AbsoluteUri}catch{$avatar=[string]$script:socialState.LocalAvatarPath}
  }
  $mine=[pscustomobject]@{
   UserId=[string]$script:socialState.UserId;Username=$name;Bio=$bio;AvatarUrl=$avatar;
   ActivityLabel=$activityLabel;TrackText=$trackText;Initial=$initial
  }
  $rows=@($mine)+@($others)
  $ui.SocialUsers.ItemsSource=$rows
  $ui.SocialEmpty.Visibility='Collapsed'
  $ui.SocialCount.Text="$($rows.Count) görünür kullanıcı çevrimiçi"
  $ui.Count.Text="$($rows.Count) kullanıcı aktif"
 } catch {}
}
function Invoke-MediaCommand([string]$command) {
 switch($command){
  'toggle' {
   if(-not $script:current){
    if(-not (Get-SelectedTrack) -and $ui.Tracks.Items.Count -gt 0){$ui.Tracks.SelectedIndex=0}
    Play-Selection
   } elseif($script:playing){
    $player.Pause();$script:playing=$false;$ui.Play.Content='▶'
    [void](Send-AteshSocialStatus $true '' '')
    Update-SocialLocalPreview
    Save-Playback
   } else {
    $player.Play();$script:playing=$true;$ui.Play.Content='Ⅱ'
    [void](Send-AteshSocialStatus $true ([string]$script:current.Title) ([string]$script:current.Artist))
    Update-SocialLocalPreview
   }
  }
  'next' {Move-Track 1;Update-SocialLocalPreview}
  'previous' {if($script:current -and $player.Position.TotalSeconds -gt 3){$player.Position=[TimeSpan]::Zero}else{Move-Track -1};Update-SocialLocalPreview}
  'stop' {$player.Stop();$script:pendingSeek=$null;$script:playing=$false;$ui.Play.Content='▶';$ui.Seek.Value=0;$ui.Elapsed.Text='0:00';[void](Send-AteshSocialStatus $true '' '');Update-SocialLocalPreview;Save-Playback}
 }
 Sync-Mini
}
function Handle-PlaybackKey($e, $focus=[Windows.Input.Keyboard]::FocusedElement, $modifiers=[Windows.Input.Keyboard]::Modifiers) {
 if($e.IsRepeat -or $ui.CollectionOverlay.Visibility -eq 'Visible'){return}
 if($focus -is [Windows.Controls.Primitives.TextBoxBase] -or $focus -is [Windows.Controls.PasswordBox] -or $focus -is [Windows.Controls.ComboBox]){return}
 if($e.Key -eq 'Space' -and $modifiers -eq [Windows.Input.ModifierKeys]::None -and $focus -isnot [Windows.Controls.Primitives.ButtonBase]){Invoke-MediaCommand 'toggle';$e.Handled=$true}
 elseif($modifiers -eq [Windows.Input.ModifierKeys]::Control -and $e.Key -eq 'Right'){Invoke-MediaCommand 'next';$e.Handled=$true}
 elseif($modifiers -eq [Windows.Input.ModifierKeys]::Control -and $e.Key -eq 'Left'){Invoke-MediaCommand 'previous';$e.Handled=$true}
}
function Show-Mini {
 Sync-Mini
 if(-not $mini.IsVisible){$area=[Windows.SystemParameters]::WorkArea;$mini.Left=[Math]::Max($area.Left,$area.Right-$mini.Width-24);$mini.Top=[Math]::Max($area.Top,$area.Bottom-$mini.Height-24);$mini.Show()}
 $window.WindowState='Minimized';[void]$mini.Activate()
}
function Show-Main {$mini.Hide();$window.WindowState='Normal';[void]$window.Activate()}
$ui.MiniToggle.Add_Click({Show-Mini})
$miniUi.MiniExpand.Add_Click({Show-Main})
$miniUi.MiniClose.Add_Click({Show-Main})
$miniUi.MiniPin.Add_Click({$mini.Topmost=-not $mini.Topmost;$miniUi.MiniPin.Content=if($mini.Topmost){'Üstte ✓'}else{'Üstte'};Save-Playback})
$miniUi.MiniDrag.Add_MouseLeftButtonDown({param($sender,$e) if($e.OriginalSource -is [Windows.Controls.TextBlock] -or $e.OriginalSource -eq $miniUi.MiniDrag){$mini.DragMove()}})
$miniUi.MiniPlay.Add_Click({Invoke-MediaCommand 'toggle'})
$miniUi.MiniNext.Add_Click({Invoke-MediaCommand 'next'})
$miniUi.MiniPrev.Add_Click({Invoke-MediaCommand 'previous'})
$miniUi.MiniVolume.Add_ValueChanged({$ui.Volume.Value=$miniUi.MiniVolume.Value})
$miniUi.MiniSeek.Add_PreviewMouseLeftButtonUp({if($player.NaturalDuration.HasTimeSpan){$player.Position=[TimeSpan]::FromSeconds($miniUi.MiniSeek.Value);Save-Playback}})
$miniUi.MiniSeek.Add_PreviewKeyUp({if($player.NaturalDuration.HasTimeSpan){$player.Position=[TimeSpan]::FromSeconds($miniUi.MiniSeek.Value);Save-Playback}})
$window.Add_PreviewKeyDown({param($sender,$e) Handle-PlaybackKey $e})
$mini.Add_PreviewKeyDown({param($sender,$e) Handle-PlaybackKey $e})
$mini.Add_Closing({param($sender,$e) if(-not $script:closingAll){$e.Cancel=$true;Show-Main}})
$mini.Add_SourceInitialized({[DostScene]::DarkTitle(([Windows.Interop.WindowInteropHelper]::new($mini)).Handle)})
$window.Add_SourceInitialized({
 $script:mediaKeys=[AteshMediaKeys]::new(([Windows.Interop.WindowInteropHelper]::new($window)).Handle)
 $script:mediaKeys.Add_Command({param($sender,$e) Invoke-MediaCommand $e.Command})
 if($script:mediaKeys.RegisteredCount -lt 4){$ui.Status.Text='Bazı medya tuşları başka uygulamada kullanımda. Boşluk ve Ctrl+ok kısayollarını kullanabilirsin.'}
})
$window.Add_Closing({Save-Playback})
$window.Add_Closed({$script:closingAll=$true;$mini.Close();if($script:mediaKeys){$script:mediaKeys.Dispose()}})
